library(testthat)
library(ONION)

test_check("ONION")